﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Text;
using System.Windows.Forms;

//information will be saved to the table in a static variable dictionary when program is running and clear once saved
namespace WindowsFormsApp1

{
    public partial class Form1 : Form
    {
        private int charIndex = 0;
        private string currentText = "";
        private Timer checkTimer = new Timer();
        private Dictionary<char, string> digits = new Dictionary<char, string>  //store the character and binary order of check boxes in the grid in a dictionary
    {
    {'A', "00000001111001001001111001001001001"},
    {'B', "111100100010100010111100100010100010111100"},  //letters were formatted to create a pattern resembling the letter 0 is empty and 1 is checked
    { 'C', "000000111000100000111" },
    { 'D', "111100100010100010100010100010100010111100" },
    { 'E', "0111000100000111000100000111" },
    { 'F', "001110001000001110001000001" },
    { 'G', "01111001000001011001001001111" },
    { 'H', "0000000101000111000101" },
    { 'I', "0000000111000010000111" },
    { 'J', "000000011100001000011" },
    { 'K', "00101000111000100000111000101" },
    { 'L', "0100000100000111" },
    { 'M', "00000001010010101" },
    { 'N', "0000000101001010" },
    { 'O', "01111001001001001001111" },
    { 'P', "001110001010001110001000001" },
    { 'Q', "001110001010001110000011" },
    { 'R', "01110001010001100001010001001" },
    { 'S', "01111001000001111000001001111" },
    { 'T', "00000011100001000001" },
    { 'U', "0101000101000111" },
    { 'V', "1000010100100011" },
    { 'W', "10101010101011111" },
    { 'X', "100001010010001100001100010010100001" },
    { 'Y', "0100100111100011000011" },
    { 'Z', "111111000010000100001000010000111111" },
    {'0', "011111010011010101011001011111"},
    {'1', "0010000110000010000111"},
    { '2', "0111000001000011000100000111" },
    { '3', "0000000111000000100011100000100111" },
    { '4', "0101000111100001000001" },
    { '5', "00111000100000111000001000111" },
    { '6', "0110000100000111000101000111" },
    { '7', "01111000010000100001" },
    { '8', "01111001001000110000110001001001111" },
    { '9', "0111000101000111000001000001" },

    };
        private void checkedBox(char character)
        {
            if (digits.TryGetValue(character, out var pattern))
            {

                for (int i = 0; i < pattern.Length; i++)
                {
                    var checkBox = tableLayoutPanel1.Controls[i] as CheckBox;
                    if (checkBox != null)
                    {
                        checkBox.Checked = pattern[i] == '1';
                    }
                }
            }
        }
        public Form1()
        {
            InitializeComponent();
            createComboboxCharacters();
            createTableLayoutPanel1();
            createTableLayoutPanel2();
            checkTimer.Interval = 900; 
            checkTimer.Tick += characterTimerTick;
            tabControl1.TabPages[0].Text = "Define Character";
            tabControl1.TabPages[1].Text = "Matrix Display";
            CreateFileMenu(); //create the file menu
            listView1.View = View.Details;
            listView1.GridLines = true;
            listView1.FullRowSelect = true;
      
        }
        private void createComboboxCharacters()
        {
            for (char c = 'A'; c <= 'Z'; c++)  //add a-z to the combobox
            {
                comboBox1.Items.Add(c.ToString());
            }

            for (int i = 0; i <= 9; i++)   //add 0-9 to the combobox
            {
                comboBox1.Items.Add(i.ToString());
            }
        }
        private void createTableLayoutPanel1()
        {
            int rowCount = 7; //create the grid of checkboxes
            int columnCount = 6;
            tableLayoutPanel1.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
            tableLayoutPanel1.AutoSize = true;
            for (int i = 0; i < rowCount; i++)
            {
                for (int j = 0; j < columnCount; j++)
                {
                    CheckBox checkBox = new CheckBox();
                    checkBox.Margin = new Padding(0);
                    checkBox.Padding = new Padding(0);
                    checkBox.Appearance = Appearance.Button;
                    checkBox.CheckedChanged += CheckBox_CheckedChanged;
                    checkBox.Size = new Size(20, 20);
                    tableLayoutPanel1.Controls.Add(checkBox, j, i);
                }
            }
            tableLayoutPanel1.ColumnStyles.Clear();
            tableLayoutPanel1.RowStyles.Clear();
        }
        private void CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            if (checkBox != null)
            {
                if (checkBox.Checked)
                {
                    checkBox.BackColor = Color.Blue; // Set to solid blue when checked
                    checkBox.ForeColor = Color.White;
                }
                else
                {
                    // Sets to another white when not checked
                    checkBox.BackColor = Color.White;
                    checkBox.ForeColor = Color.Black;
                }
            }
        }
        private void CheckBox_CheckedChanged2(object sender, EventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            if (checkBox != null)
            {
                if (checkBox.Checked)
                {
                    // Set to solid blue when checked
                    checkBox.BackColor = Color.Blue;
                    checkBox.ForeColor = Color.White;
                }
                else
                {
                    // Sets to another white when not checked
                    checkBox.BackColor = Color.White;
                    checkBox.ForeColor = Color.Black;
                }
            }
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem != null)
            {
                char selectedChar = comboBox1.SelectedItem.ToString()[0];
                clearCheckBoxes();
                checkedBox(selectedChar);

            }
            else
            {
                // Handles the case when no item is selected
                clearCheckBoxes();
            }
        }
        private void displayCharacter(char character) //tablepanel1 display character
        {
            if (digits.TryGetValue(character, out var pattern))
            {

                string binaryPattern = getPattern(pattern);

                ListViewItem item = new ListViewItem(character.ToString());
                item.SubItems.Add(binaryPattern);

                listView1.Items.Add(item);
            }
        }
        private string getPattern(string pattern) //tablepanel1 pattern constructor
        {
            StringBuilder binaryPattern = new StringBuilder();

            foreach (char c in pattern)
            {
                binaryPattern.Append(c);
            }

            return binaryPattern.ToString();
        }
        private void clearCheckBoxes() //table layoutpanel1 clear function
        {
            foreach (Control control in tableLayoutPanel1.Controls)
            {
                if (control is CheckBox checkBox)
                {
                    checkBox.Checked = false;
                }
            }
        }
       private void CreateFileMenu()
        {
            MenuStrip menuStrip = new MenuStrip();
            this.MainMenuStrip = menuStrip;
            ToolStripMenuItem fileMenu = new ToolStripMenuItem("File");
            menuStrip.Items.Add(fileMenu);
            ToolStripMenuItem exitMenuItem = new ToolStripMenuItem("Exit");
            exitMenuItem.Click += ExitMenuItem_Click;
            fileMenu.DropDownItems.Add(exitMenuItem);
        }
        private void ExitMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        //saves the pattern to a new dictionary in a static variable
        public static Dictionary<char, string> savedPatterns = new Dictionary<char, string>();
        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == -1)
            {
                errorProvider3.SetError(comboBox1, "Please select a value.");
            }
            else
            {
                DialogResult result = MessageBox.Show("Are you sure to save?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    // If the user clicked yes save
                    char selectedChar = comboBox1.SelectedItem.ToString()[0];
                    string pattern = assemblePattern();

                    // save to static variable
                    savedPatterns[selectedChar] = pattern.Replace(Environment.NewLine, ""); // remove new lines

                    // Clear the combo box and  checkboxes
                    comboBox1.SelectedIndex = -1;
                    comboBox1.Text = "";
                    clearCheckBoxes();

                    errorProvider3.SetError(comboBox1, null);

                    displayCharacter(selectedChar);
                }
            }
        }
        private string assemblePattern()
        {
            StringBuilder patternChecker = new StringBuilder();
            int rowCount = tableLayoutPanel1.RowCount;
            int columnCount = tableLayoutPanel1.ColumnCount;

            for (int row = 0; row < rowCount; row++)
            {
                for (int col = 0; col < columnCount; col++)
                {

                    Control control = tableLayoutPanel1.GetControlFromPosition(col, row);
                    if (control is CheckBox checkBox)
                    { 
                        patternChecker.Append(checkBox.Checked ? '1' : '0'); //if checkbox checked append 1 if checkbox != checked append 0
                    }
                }
                if (row < rowCount - 1)
                {
                    patternChecker.AppendLine();
                }
            }
            return patternChecker.ToString();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = -1;
            comboBox1.Text = "";
            foreach (Control cb in tableLayoutPanel1.Controls)
            {
                if (cb is CheckBox)
                {
                    ((CheckBox)cb).Checked = false;
                }
            }
        }
        private void comboBox1_Validating(object sender, CancelEventArgs e)
        {
            if (string.IsNullOrEmpty(comboBox1.Text))
            {
                e.Cancel = true;
                comboBox1.Focus();
                errorProvider3.SetError(comboBox1, "please slect a value.");

            }
            else
            {
                e.Cancel = false;
                errorProvider3.SetError(comboBox1, null);
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            var result = colorDialog1.ShowDialog();// Open the color dialog and check if the user selected a color
            if (result == DialogResult.OK)
            {
                Color selectedColor = colorDialog1.Color; // Get the selected color from the color dialog

                foreach (Control control in tableLayoutPanel2.Controls) // Iterate through all controls in tableLayoutPanel2
                {
                    if (control is CheckBox checkBox && checkBox.Checked)// Check if the control is a CheckBox and if it is checked
                    {
                        checkBox.BackColor = selectedColor; // Set the background color of the checked checkbox
                    }
                }
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            characterFormation(textBox1.Text);
        }
        private void button3_Click(object sender, EventArgs e)
        {

            textBox1.Text = "";
         
            ClearTableLayoutPanel2Checkboxes();  // Call to clear all checkboxes in tableLayoutPanel2
        }
        private void Fix_CheckedChanged(object sender, EventArgs eargs)
        {
            label2.Text = "Done! ";
            checkTimer.Stop();
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs eargs)
        {
            radioButton2.CheckedChanged += radioButton2_CheckedChanged;
            charIndex = 0;
            label2.Text = "Processing! ";
            checkTimer.Start();
        }
        private void characterTimerTick(object sender, EventArgs e)
        {
            if (charIndex < currentText.Length)
            {
             
                characterFormation(currentText.Substring(0, charIndex + 1)); // Display the text up to the current charIndex increasing it each tick.
                charIndex++; // Move to the next character.
            }
            else
            {
               
                checkTimer.Stop();
                label2.Text = "Done!";
            }
        }
        private void viewHelpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewHelp f = new ViewHelp();
            f.Show();
        }
        private void contactUsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ContactUs f = new ContactUs();
            f.Show();
        }
        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }
       
        private void button4_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                    currentText = textBox1.Text.ToUpper();
                    charIndex = 0;
                   characterFormation(textBox1.Text);
            if (radioButton1.Checked)
                {
                    checkTimer.Stop();
                    label2.Text = "Processing...";
                    Application.DoEvents(); //update UI
                    characterFormation(textBox1.Text);
                    label2.Text = "Done!";
                }
            else if (radioButton2.Checked)
            {
                    label2.Text = "Processing...";
                    Application.DoEvents(); // update UI 
                    characterFormation(textBox1.Text);
                    checkTimer.Stop();// Reset and start the timer 
                    checkTimer.Start();
            }
            }
            else
            {
                characterFormation(currentText);
                label2.Text = "Done!";
            }
        }
        private void characterFormation(string input)
        {
            input = input.ToUpper();  // Handle case sensitivity
            int columnCount = 6; // Each character pattern is 6 columns

            ClearTableLayoutPanel2Checkboxes(); // Clear checkboxes before updating

            if (string.IsNullOrEmpty(input))
            {
                return; // If there is no input exit
            }

            for (int charIndex = 0; charIndex < input.Length; charIndex++)
            {
                char character = input[charIndex];
                if (digits.TryGetValue(character, out var pattern))
                {
                    for (int i = 0; i < pattern.Length; i++)
                    {
                        int rowIndex = i / columnCount;
                        int colIndex = charIndex * columnCount + (i % columnCount);
                        CheckBox checkBox = tableLayoutPanel2.GetControlFromPosition(colIndex, rowIndex) as CheckBox;
                        if (checkBox != null)
                        {
                            checkBox.Checked = pattern[i] == '1';
                        }
                    }
                }
            }
        }
        private void createTableLayoutPanel2() //create grid of checkboxes in tab2
        {
            int rowCount = 7;
            int columnCount = 30;
            tableLayoutPanel2.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
            tableLayoutPanel2.AutoSize = true;
            for (int i = 0; i < rowCount; i++)
            {
                for (int j = 0; j < columnCount; j++)
                {
                    CheckBox checkBox = new CheckBox();
                    checkBox.Margin = new Padding(0);
                    checkBox.Padding = new Padding(0);
                    checkBox.Appearance = Appearance.Button;
                    checkBox.CheckedChanged += CheckBox_CheckedChanged;
                    checkBox.Size = new Size(20, 20);

                    tableLayoutPanel2.Controls.Add(checkBox, j, i);
                }
            }
            tableLayoutPanel2.ColumnStyles.Clear();
            tableLayoutPanel2.RowStyles.Clear();
        }
        private void ClearTableLayoutPanel2Checkboxes() //when function is called we will reset the tablelayout to none checked
        {
            foreach (Control control in tableLayoutPanel2.Controls)
            {
                if (control is CheckBox checkBox)
                {
                    checkBox.Checked = false;
                }
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}